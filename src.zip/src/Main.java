
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Board gameBoard = new Board();
		//Control controlPanel = new Control();
		//gameBoard.testRooms();
		//controlPanel.panel();
		//gameBoard.DrawPlayer(PlayerIdentity, X, Y, )
		
		
	}

}
